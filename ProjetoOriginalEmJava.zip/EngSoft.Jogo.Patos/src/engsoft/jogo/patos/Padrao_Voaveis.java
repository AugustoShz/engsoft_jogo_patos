package engsoft.jogo.patos;

public interface Padrao_Voaveis {

	String voar();
	
	double getVelocidade();

}
