package engsoft.jogo.patos;

/**
 * Classe de Apito que pode efetuar um grasno
 * Implementa��o da Interface
 * @author rodrigo.vieira
 */
public class Apito implements Padrao_Grasnar{

	public String grasnar()
	{		
		return "Queeeeee";
	}
}
