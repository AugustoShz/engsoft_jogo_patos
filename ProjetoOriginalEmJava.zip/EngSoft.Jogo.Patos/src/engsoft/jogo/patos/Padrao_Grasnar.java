package engsoft.jogo.patos;

public interface Padrao_Grasnar {

	String grasnar();

}
